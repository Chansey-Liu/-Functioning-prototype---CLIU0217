// Creating 3D vision using WEBGL patterns is a technique that requires advanced graphics programming
/* This technique implements concepts from:
- Creating and managing 3D scenes
- Working with geometry and transformations
- Implementing particle systems and animations
- Using noise for organic movement
*/

// Scene class represents the main 3D scene containing various elements with dynamic behavior
class Scene {
  constructor() {
    // Define the color palette used throughout the scene
    this.colors = {
      background: '#F1F2ED', // Light neutral background
      red: '#A03225',       // Accent red
      blue: '#486FBE',      // Accent blue
      grey: '#D8D6C7',      // Neutral grey
      yellow: '#EBD42B',    // Accent yellow
      line: '#606060'       // Dark grey for lines
    };
    
    // Define the configurations for plates in the scene
    // Each plate has position (x,y,z), dimensions (w,h,d), and color
    this.plateConfigs = [
      // Base grey plates for structural foundation
      { x: -200, y: -130, z: -40, w: 200, h: 10, d: 80, color: this.colors.grey },
      { x: -50, y: 200, z: -20, w: 200, h: 10, d: 80, color: this.colors.grey },
      
      // Feature plates with different colors for visual interest
      { x: 100, y: 0, z: -15, w: 120, h: 10, d: 100, color: this.colors.blue },
      { x: -150, y: 50, z: -30, w: 80, h: 10, d: 80, color: this.colors.red },
      { x: -10, y: -50, z: -25, w: 80, h: 10, d: 80, color: this.colors.red },
      { x: 200, y: 100, z: -10, w: 80, h: 10, d: 180, color: this.colors.yellow },
      { x: -250, y: 30, z: -20, w: 80, h: 10, d: 200, color: this.colors.yellow },
      { x: 130, y: -150, z: 0, w: 200, h: 10, d: 80, color: this.colors.yellow },
    ];
    
    // Initialize arrays to store different scene elements
    this.plates = [];         // Stores plate objects
    this.randomBoxes = [];    // Stores floating box objects
    this.freeParticles = [];  // Stores particle system elements

    // Random offsets for Perlin noise to create organic movement
    this.sceneNoiseOffset = {
      x: random(1000),
      y: random(2000),
      z: random(3000),
      rotationX: random(5000),
      rotationY: random(5000)
    };

    // Initialize all scene components
    this.initializePlates(); 
    this.initializeRandomBoxes();
    this.initializeFreeParticles();
  }

  // Creates a particle system with 200 individual particles
  initializeFreeParticles() {
    const numParticles = 200;
    for (let i = 0; i < numParticles; i++) {
      this.freeParticles.push(new FreeParticle(this.colors));
    }
  }

  // Converts plate configurations into Plate objects
  initializePlates() {
    this.plates = this.plateConfigs.map(config => 
      new Plate(config.x, config.y, config.z, config.w, config.h, config.d, config.color)
    );
  }

  // Creates random floating boxes positioned relative to existing plates
  initializeRandomBoxes() {
    let boxCount = 20;
    for (let i = 0; i < boxCount; i++) {
      let boxColor = random([this.colors.red, this.colors.blue, this.colors.grey, this.colors.yellow]);
      let boxSize = random(5, 15);
      let basePlate = random(this.plates);
      // Position boxes with slight random offset from base plate
      let boxX = basePlate.x + random(-10, 10);
      let boxY = basePlate.y + random(-10, 10);
      let boxZ = random(-40, -300);
      
      this.randomBoxes.push(new RandomBox(boxX, boxY, boxZ, boxSize, boxColor));
    }
  }

  // Main draw function that updates and renders all scene elements
  draw() {
    background(this.colors.background);
    
    let time = frameCount * 0.002;  // Time factor for animations
    
    // Calculate scene-wide transformations using Perlin noise
    let sceneXOffset = map(noise(time + this.sceneNoiseOffset.x), 0, 1, -100, 100);
    let sceneYOffset = map(noise(time + this.sceneNoiseOffset.y), 0, 1, -100, 100);
    let sceneZOffset = map(noise(time + this.sceneNoiseOffset.z), 0, 1, -30, 30);
    
    let sceneRotX = map(noise(time + this.sceneNoiseOffset.rotationX), 0, 1, -0.3, 0.3);
    let sceneRotY = map(noise(time + this.sceneNoiseOffset.rotationY), 0, 1, -0.5, 0.5);
    
    // Apply scene-wide transformations
    push();
    translate(sceneXOffset, sceneYOffset, sceneZOffset);
    rotateX(sceneRotX);
    rotateY(sceneRotY);
    
    // Draw all scene elements
    for (let plate of this.plates) {
      plate.draw();
    }

    for (let box of this.randomBoxes) {
      box.update();
      box.display();
    }

    for (let particle of this.freeParticles) {
      particle.update();
      particle.display();
    }
    
    pop();
  }
}
// Plate class represents a flat geometric plane in 3D space with vertical supports
class Plate {
  constructor(x, y, z, width, height, depth, color) {
    // Basic properties
    this.x = x;
    this.y = y;
    this.z = z;
    this.width = width;
    this.height = height;
    this.depth = depth;
    this.color = color;

    // Unique noise offsets for organic movement
    this.noiseOffset = {
      x: random(1000),
      y: random(2000),
      z: random(3000),
      rotationX: random(4000),
      rotationY: random(5000),
      scale: random(6000)
    };

    // Array to store vertical support lines
    this.verticalLines = [];
    this.initializeVerticalLines();
  }

  // Creates vertical lines at each corner of the plate
  initializeVerticalLines() {
    // Define corner positions relative to plate center
    const corners = [
      { x: -this.width/2, y: -this.depth/2 },
      { x: this.width/2, y: -this.depth/2 },
      { x: -this.width/2, y: this.depth/2 },
      { x: this.width/2, y: this.depth/2 }
    ];

    // Create vertical lines at each corner
    for (let corner of corners) {
      this.verticalLines.push(new VerticalLine(
        this.x + corner.x,
        this.y + corner.y,
        this.z,
        300,  // Height of vertical lines
        5,    // Width of vertical lines
        '#606060'  // Color of vertical lines
      ));
    }
  }

  // Renders the plate with dynamic transformations
  draw() {
    push();
    
    let time = frameCount * 0.006;  // Time factor for animations
    
    // Calculate dynamic offsets using Perlin noise
    let xOff = map(noise(time + this.noiseOffset.x), 0, 1, -2, 2);
    let yOff = map(noise(time + this.noiseOffset.y), 0, 1, -2, 2);
    let zOff = map(noise(time + this.noiseOffset.z), 0, 1, -2, 2);
    
    // Calculate rotation angles using Perlin noise
    let rotX = map(noise(time + this.noiseOffset.rotationX), 0, 1, -0.1, 0.1);
    let rotY = map(noise(time + this.noiseOffset.rotationY), 0, 1, -0.1, 0.1);
    
    // Calculate scale variation using Perlin noise
    let scaleVar = map(noise(time + this.noiseOffset.scale), 0, 1, 0.98, 1.02);
    
    // Draw the main plate
    push();
    translate(this.x + xOff, this.y + yOff, this.z + zOff);
    rotateX(rotX);
    rotateY(rotY);
    scale(scaleVar);
    
    fill(this.color);
    noStroke();
    box(this.width, this.depth, this.height);
    pop();
    
    // Draw vertical support lines with the same transformations
    for (let line of this.verticalLines) {
      push();
      translate(xOff, yOff, zOff);
      rotateX(rotX);
      rotateY(rotY);
      line.draw(scaleVar);
      pop();
    }
    
    pop();
  }
}

// VerticalLine class represents support structures extending vertically from plates
class VerticalLine {
  constructor(x, y, z, height, width, color) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.height = height;
    this.width = width;
    this.color = color;
  }

  // Renders the vertical line with parent's scale factor
  draw(parentScale) {
    push();
    translate(this.x, this.y, this.z - this.height/2);
    scale(1, 1, parentScale);
    
    fill(this.color);
    noStroke();
    box(this.width, this.width, this.height);
    pop();
  }
}

// RandomBox class represents floating boxes with organic movement
class RandomBox {
  constructor(x, y, z, size, color) {
    // Initial position
    this.x = x;
    this.y = y;
    this.z = z;
    this.size = size;
    this.color = color;
    
    // Store original position for reference
    this.originalX = this.x;
    this.originalY = this.y;
    this.originalZ = this.z;
    
    // Unique noise offsets for organic movement
    this.noiseOffsetX = random(1000);
    this.noiseOffsetY = random(2000);
    this.noiseOffsetZ = random(3000);
  }

  // Updates position and rotation using Perlin noise
  update() {
    let noiseScale = 0.001;  // Scale factor for noise
    let amplitude = 500;     // Movement range
    
    // Calculate new position using Perlin noise
    this.x = this.originalX + (noise(this.noiseOffsetX + frameCount * noiseScale) - 0.5) * amplitude;
    this.y = this.originalY + (noise(this.noiseOffsetY + frameCount * noiseScale) - 0.5) * amplitude;
    this.z = this.originalZ + (noise(this.noiseOffsetZ + frameCount * noiseScale) - 0.5) * amplitude;
    
    // Calculate rotation angles using Perlin noise
    this.rotationX = noise(this.noiseOffsetX + frameCount * noiseScale) * TWO_PI;
    this.rotationY = noise(this.noiseOffsetY + frameCount * noiseScale) * TWO_PI;
    this.rotationZ = noise(this.noiseOffsetZ + frameCount * noiseScale) * TWO_PI;
  }

  // Renders the box with current transformations
  display() {
    push();
    translate(this.x, this.y, this.z);
    rotateX(this.rotationX);
    rotateY(this.rotationY);
    rotateZ(this.rotationZ);
    noStroke();
    fill(this.color);
    box(this.size);
    pop();
  }
}

// FreeParticle class represents small particles moving in a custom pattern
class FreeParticle {
  constructor(colors) {
    // Initialize particle with polar coordinates
    let angle = random(TWO_PI);
    let r = random(150);
    let freeShape = this.getFreeShape(cos(angle) * r, sin(angle) * r);
    
    // Set initial position
    this.x = freeShape.x;
    this.y = freeShape.y;
    this.z = random(-100, 100);
    
    this.size = random(5, 10);
    // Randomly select color with higher probability for yellow
    this.color = random([colors.red, colors.blue, colors.grey, colors.yellow, colors.yellow]);
    
    // Store original position for reference
    this.originalX = this.x;
    this.originalY = this.y;
    this.originalZ = this.z;
    
    // Unique noise offsets for organic movement
    this.noiseOffsetX = random(1000);
    this.noiseOffsetY = random(2000);
    this.noiseOffsetZ = random(3000);
  }

  // Transforms coordinates to create custom movement pattern
  getFreeShape(x, y) {
    let scale = 4.5;
    let newX = x;
    let newY = y;
    
    // Apply different transformations based on x position
    if (x > 0) {
      newY = y * (1 - x/200) + sin(x/30) * 20;
      newX = x * 0.8;
    } else {
      newY = y * (1 + x/200) + sin(x/30) * 20;
      newX = x * 0.8;
    }
    
    return {x: newX * scale, y: newY * scale};
  }

  // Updates position and rotation using Perlin noise
  update() {
    let noiseScale = 0.001;
    let amplitude = 5000;
    
    // Calculate new position using Perlin noise
    this.x = this.originalX + (noise(this.noiseOffsetX + frameCount * noiseScale) - 0.5) * amplitude;
    this.y = this.originalY + (noise(this.noiseOffsetY + frameCount * noiseScale) - 0.5) * amplitude;
    this.z = this.originalZ + (noise(this.noiseOffsetZ + frameCount * noiseScale) - 0.5) * amplitude;
    
    // Calculate rotation angles using Perlin noise
    this.rotationX = noise(this.noiseOffsetX + frameCount * noiseScale) * TWO_PI;
    this.rotationY = noise(this.noiseOffsetY + frameCount * noiseScale) * TWO_PI;
    this.rotationZ = noise(this.noiseOffsetZ + frameCount * noiseScale) * TWO_PI;
  }

  // Renders the particle with current transformations
  display() {
    push();
    translate(this.x, this.y, this.z);
    rotateX(this.rotationX);
    rotateY(this.rotationY);
    rotateZ(this.rotationZ);
    noStroke();
    fill(this.color);
    box(this.size);
    pop();
  }
}

// Global scene instance
let scene;

// p5.js setup function - initializes the canvas and scene
function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);  // Create 3D canvas
  camera(-800, 800, 600, 0, 0, 0, 0, 0, -1);      // Set camera position and orientation
  scene = new Scene();                             // Initialize scene
}

// p5.js draw function - updates and renders the scene each frame
function draw() {
  scene.draw();
  orbitControl();  // Enable mouse control of camera
}

// p5.js windowResized function - handles window resize events
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);  // Adjust canvas size to window
}